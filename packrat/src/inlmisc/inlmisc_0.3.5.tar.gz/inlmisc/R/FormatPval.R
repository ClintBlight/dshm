#' Format P Values
#'
#' This function is intended for formatting \emph{p}-values.
#' Scientific notation is written with LaTeX commands.
#'
#' @param x 'numeric'.
#'   Vector of p-values.
#' @param digits 'integer'.
#'   Number of significant digits to be used.
#' @param eps 'numeric'.
#'   Numerical tolerance;
#'   values less than \code{eps} are formatted as \code{"< [eps]"}.
#' @param na.form 'character'.
#'   Value used for missing values.
#' @param scientific 'logical'.
#'   Indicates whether values should be encoded in scientific format.
#'   A missing value lets \R decide whether fixed or scientific notation is used.
#'
#' @return A 'character' vector of formatted \emph{p}-values.
#'
#' @author J.C. Fisher, U.S. Geological Survey, Idaho Water Science Center
#'
#' @seealso \code{\link{ToScientific}}
#'
#' @keywords utilities
#'
#' @export
#'
#' @examples
#' x <- c(stats::runif(5), pi^-100, NA)
#' FormatPval(x)
#' format.pval(x)
#'
#' x <- c(0.1, 0.0001, 1e-27)
#' FormatPval(x, scientific = TRUE)
#' FormatPval(x, digits = 3L, eps = 0.001)
#'

FormatPval <- function(x, digits=max(1, getOption("digits") - 2),
                       eps=.Machine$double.eps, na.form="NA", scientific=NA) {

  checkmate::assertNumeric(x)
  checkmate::assertInt(digits, null.ok=TRUE)
  checkmate::assertNumber(eps)
  checkmate::assertCharacter(na.form, len=1)
  checkmate::assertLogical(scientific, len=1)

  p <- format(round(x, digits), nsmall=digits, scientific=FALSE)

  is <- if (is.na(scientific)) grepl("e", formatC(x)) else rep(scientific, length(x))
  p[is] <- ToScientific(x[is], digits=0L)

  lim <- ifelse(grepl("e", formatC(eps)), ToScientific(eps, digits=0L), format(eps))
  p[x < eps] <- sprintf("< %s", lim)

  p[is.na(x)] <- as.character(na.form)

  return(p)
}
